<?php 
    header("Location:./Views/mainpage/main.php");
?>